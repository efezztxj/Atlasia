import { useEffect, useState } from "react";
import { Bookmark, Camera, ChevronLeft, ChevronRight, ExternalLink, Map, MapPin, Route, Share2, X } from "lucide-react";
import type { Place } from "../types";
import { STORIES } from "../data/galleries";
import { CATEGORY_MAP } from "../data/categories";
import { usePlaceGallery } from "../hooks/usePlaceGallery";
import { useCollections } from "../hooks/useCollections";
import { usePanelAccess } from "../hooks/usePanelAccess";
import { advice } from "../utils/placeAdvice";

interface Props { place: Place; onClose: () => void; onStreet: () => void; onPlan: () => void; }

export default function PlaceDetails({ place, onClose, onStreet, onPlan }: Props) {
  const { photos: allPhotos, loading, error } = usePlaceGallery(place);
  const { savePlace, isSaved } = useCollections();
  const panelRef = usePanelAccess(true, onClose, true);
  const [failed, setFailed] = useState<string[]>([]);
  const [index, setIndex] = useState(0);
  const [status, setStatus] = useState<string | null>(null);
  const [imageLoaded, setImageLoaded] = useState(false);
  const photos = allPhotos.filter((photo) => !failed.includes(photo.url));
  const photo = photos[Math.min(index, Math.max(0, photos.length - 1))];
  const cat = CATEGORY_MAP[place.category];
  const guide = advice(place);
  const story = place.story ?? STORIES[place.id] ?? place.note;
  useEffect(() => { setFailed([]); setIndex(0); setStatus(null); }, [place.id]);
  useEffect(() => setImageLoaded(false), [photo?.url]);
  const share = async () => {
    try {
      const text = `${place.title}\n${place.region}\nhttps://www.openstreetmap.org/?mlat=${place.lat}&mlon=${place.lng}#map=16/${place.lat}/${place.lng}`;
      if (navigator.share) await navigator.share({ title: place.title, text });
      else await navigator.clipboard.writeText(text);
      setStatus("Yer bağlantısı paylaşıldı.");
    } catch { setStatus("Paylaşım tamamlanmadı. Konum bağlantısını yol tarifi üzerinden açabilirsin."); }
  };
  return <div className="fixed inset-0 z-[65] flex justify-end bg-black/35"><button type="button" className="absolute inset-0" onClick={onClose} aria-label="Yer detayından haritaya dön" /><aside ref={panelRef} role="dialog" aria-modal="true" aria-labelledby="place-title" className="settings-sheet relative flex h-dvh w-full max-w-[510px] flex-col overflow-hidden border-l border-leaf/20 bg-[#041c16] shadow-2xl">
    <header className="absolute inset-x-0 top-0 z-10 flex items-center justify-between bg-gradient-to-b from-ink/95 to-transparent px-4 py-3"><button type="button" onClick={onClose} className="flex min-h-11 items-center gap-1.5 rounded-full bg-ink/85 px-3 text-sm"><ChevronLeft size={17} />Haritaya dön</button><button type="button" onClick={onClose} aria-label="Yer detayını kapat" className="grid size-11 place-items-center rounded-full bg-ink/85"><X size={18} /></button></header>
    <figure className="relative h-[min(35dvh,350px)] min-h-[220px] shrink-0 bg-[#12362a]">
      {photo ? <><img key={photo.url} src={photo.url} alt={`${place.title}${photo.nearby ? " yakın çevresi" : ""}, galeri fotoğrafı ${index + 1}`} className="size-full object-cover" onLoad={() => setImageLoaded(true)} onError={() => { setFailed((current) => [...current, photo.url]); setIndex(0); }} />{!imageLoaded && <div className="pointer-events-none absolute inset-0 grid place-content-center bg-ink/30 text-sm">Fotoğraf yükleniyor...</div>}<figcaption className="absolute inset-x-0 bottom-0 bg-ink/90 px-4 py-2 text-[11px] text-mint/90">{photo.nearby && <span className="mr-2 text-sun">Yakın çevreden</span>}{photo.source ? <a href={photo.source} target="_blank" rel="noreferrer" className="hover:underline">{photo.credit}</a> : photo.credit}</figcaption></> : <div className="flex size-full flex-col items-center justify-center gap-3 px-6 text-center"><Camera size={30} className="text-sun" /><p className="text-sm">{loading ? "Bu çevredeki fotoğraflar aranıyor..." : allPhotos.length ? "Fotoğraflar şu an yüklenemiyor." : "Bu noktaya henüz fotoğraf eklenmemiş."}</p>{failed.length > 0 && <button type="button" onClick={() => setFailed([])} className="min-h-10 text-sm text-sun underline">Tekrar dene</button>}</div>}
      {photos.length > 1 && <><button type="button" aria-label="Önceki fotoğraf" onClick={() => setIndex((current) => (current - 1 + photos.length) % photos.length)} className="absolute left-3 top-1/2 grid size-11 -translate-y-1/2 place-items-center rounded-full bg-ink/80"><ChevronLeft size={18} /></button><button type="button" aria-label="Sonraki fotoğraf" onClick={() => setIndex((current) => (current + 1) % photos.length)} className="absolute right-3 top-1/2 grid size-11 -translate-y-1/2 place-items-center rounded-full bg-ink/80"><ChevronRight size={18} /></button></>}
    </figure>
    {photos.length > 1 && <nav aria-label="Yer fotoğrafları" className="thin-scroll flex shrink-0 gap-2 overflow-x-auto px-4 py-3">{photos.map((item, i) => <button key={item.url} type="button" aria-label={`${i + 1}. fotoğrafı göster`} aria-current={i === index ? "true" : undefined} onClick={() => setIndex(i)} className={`h-14 w-[76px] shrink-0 overflow-hidden rounded-lg border-2 ${i === index ? "border-sun" : "border-transparent"}`}><img src={item.url} alt="" className="size-full object-cover" loading="lazy" /></button>)}</nav>}
    <div className="thin-scroll min-h-0 flex-1 overflow-y-auto px-5 pb-8 pt-3"><p className="text-[12px] font-semibold uppercase tracking-[0.16em] text-sun">{cat.label} · {place.kind === "user" ? "Gezgin izi" : "Atlasia rehberi"}</p><h2 id="place-title" className="font-display mt-2 text-[28px] font-semibold leading-tight">{place.title}</h2><p className="mt-2 flex items-center gap-1.5 text-[13px] text-mint/75"><MapPin size={14} />{place.region}</p><div className="mt-4 flex flex-wrap gap-2"><button type="button" onClick={() => savePlace(place)} className="flex min-h-11 items-center gap-2 rounded-full border border-leaf/30 px-4 text-sm text-sun"><Bookmark size={15} fill={isSaved(place.id) ? "currentColor" : "none"} />{isSaved(place.id) ? "Kaydedildi" : "Kaydet"}</button><button type="button" onClick={onPlan} className="flex min-h-11 items-center gap-2 rounded-full bg-sun px-4 text-sm font-semibold text-ink"><Route size={15} />Rota oluştur</button><button type="button" onClick={() => void share()} aria-label="Bu yeri paylaş" className="grid size-11 place-items-center rounded-full border border-leaf/30"><Share2 size={16} /></button></div>
      {status && <p role="status" className="mt-2 text-[13px] text-sun">{status}</p>}<p className="mt-5 text-[15px] leading-[1.8] text-mint/90">{story}</p>
      <h3 className="mt-7 text-[12px] font-bold uppercase tracking-[0.16em] text-sun">Gitmeden bil</h3><dl className="mt-3 space-y-4">{[["En iyi zaman", guide.timing], ["Ulaşım", guide.access], ["Bilet ve ücret", guide.cost], ["Dikkat", guide.caution]].map(([label, value]) => <div key={label}><dt className="text-[12px] text-mint/70">{label}</dt><dd className="mt-1 text-[14px] leading-relaxed text-mint">{value}</dd></div>)}</dl>
      <button type="button" onClick={onStreet} className="mt-6 flex min-h-12 w-full items-center justify-between gap-2 rounded-xl border border-leaf/30 px-4 text-[14px]"><span className="flex items-center gap-2"><Map size={17} className="text-sun" />Çevre haritasını aç</span><ExternalLink size={15} /></button><a href={`https://www.openstreetmap.org/?mlat=${place.lat}&mlon=${place.lng}#map=16/${place.lat}/${place.lng}`} target="_blank" rel="noreferrer" className="mt-2 flex min-h-11 items-center justify-center gap-2 text-[13px] text-sun">OpenStreetMap'te bu yeri aç <ExternalLink size={13} /></a>
      {error && <p className="mt-3 text-[13px] text-mint/75">Ek fotoğraf kaynağına ulaşılamadı; mevcut galeriyi kullanabilirsin.</p>}<p className="mt-5 border-l-2 border-sun/30 pl-3 text-[12px] leading-relaxed text-mint/75">Bu bir rehber özetidir. Saat, ücret ve erişim koşullarını gitmeden resmî kaynaktan doğrula.</p>
    </div>
  </aside></div>;
}